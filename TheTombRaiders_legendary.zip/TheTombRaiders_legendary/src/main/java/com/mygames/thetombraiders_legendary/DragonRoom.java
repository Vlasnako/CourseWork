package com.mygames.thetombraiders_legendary;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class DragonRoom extends Macroobject implements Initializable{

    ListView<Dovakin> DragonRoomListView;
    Label name;
    Image dragonRoom;
    ImageView dragonRoomView;
    Rectangle walls;
    Rectangle entrance;
    Rectangle dragonRoomBounds;

    public DragonRoom(double macroX, double macroY) {
        this.macroX = macroX;
        this.macroY = macroY;
        MacroCompositionStage.setResizable(false);
        dovakinNumber = new Label("0");
        walls = new Rectangle(250, 200);
        entrance = new Rectangle(70, 70);
        dragonRoomBounds = new Rectangle(300, 100);
        name = new Label("DRAGON ROOM");
        name.setFont(Font.font("Times New Roman", 20));
        dovakinNumber.setFont(Font.font("Times New Roman", 20));
        dragonRoom = new Image(DragonRoom.class.getResource("Brown_ruins1.png").toString(), 300, 250, false, false);
        dragonRoomView = new ImageView(dragonRoom);
        dragonRoomView.setX(macroX);
        dragonRoomView.setY(macroY);
        name.setLayoutX(macroX + 100);
        name.setLayoutY(macroY + 70);
        dovakinNumber.setLayoutX(macroX + 280);
        dovakinNumber.setLayoutY(macroY + 70);
        walls.setX(macroX);
        walls.setY(macroY);
        walls.setFill(Color.TRANSPARENT);
        walls.setStroke(Color.DARKORANGE);
        entrance.setX(macroX + 90);
        entrance.setY(macroY + 120);
        entrance.setFill(Color.TRANSPARENT);
        entrance.setStroke(Color.TRANSPARENT);
        dragonRoomBounds.setX(macroX - 100);
        dragonRoomBounds.setY(macroY + 40);
        dragonRoomBounds.setFill(Color.TRANSPARENT);
        dragonRoomBounds.setStroke(Color.TRANSPARENT);
        MacroCompositionStage.setScene(MacroCompositionScene);
        DragonRoomListView = new ListView<>();
        exitButton.setLayoutX(280);
        exitButton.setLayoutY(90);
        MacroCompositionGroup.getChildren().addAll(DragonRoomListView, exitButton);

        HelloApplication.group.getChildren().addAll(walls, dragonRoomView, name, entrance, dragonRoomBounds, dovakinNumber);

    }
    @Override

    public void initialize(URL url, ResourceBundle rb) {
        DragonRoomListView.setItems(dovakinsInMacroobjects);
                index = DragonRoomListView.getSelectionModel().getSelectedIndex();
    }
    public void composition (MouseEvent event) {

        if (dragonRoomView.boundsInParentProperty().get().contains(event.getX(), event.getY())) {
            DragonRoomListView.setItems(dovakinsInMacroobjects);
            MacroCompositionStage.show();
        }
        exitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                System.out.println("DOVAKIN " + dovakinsInMacroobjects.get(index) + " HAS_LEFT_THE_TOMB");
                System.out.println(index);
                Dovakin exittingDovakin = dovakinsInMacroobjects.remove(index);
                exittingDovakin.setDovakinX(macroX);
                exittingDovakin.setDovakinY(macroY + 40);
                exittingDovakin.moveImage(macroX, macroY + 40);
                exittingDovakin.appear();
                dovakinNumber.setText(Integer.toString(dovakinsInMacroobjects.size()));
            }
        });
    }





}
