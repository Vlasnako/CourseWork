package com.mygames.thetombraiders_legendary;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import java.net.URL;
import java.util.ResourceBundle;
public class Tomb extends Macroobject implements Initializable {
    private ListView <Dovakin> tombListView;
    private Label name;
    private Image tomb;
    public ImageView tombView;
    private Rectangle walls;
    private Rectangle entrance;
    private Rectangle tombBounds;
    public Tomb (double macroX, double macroY) {
        this.macroX = macroX;
        this.macroY = macroY;
        MacroCompositionStage.setResizable(false);
        dovakinNumber = new Label("0");
        walls = new Rectangle(250, 200);
        entrance = new Rectangle(70, 70);
        tombBounds = new Rectangle(300, 100);
        name = new Label("TOMB");
        name.setFont(Font.font("Times New Roman", 20));
        dovakinNumber.setFont(Font.font("Times New Roman", 20));
        tomb = new Image(Tomb.class.getResource("Sand_ruins1.png").toString(), 250, 200, false, false);
        tombView = new ImageView(tomb);
        tombView.setX(macroX);
        tombView.setY(macroY);
        name.setLayoutX(macroX + 100);
        name.setLayoutY(macroY + 70);
        dovakinNumber.setLayoutX(macroX + 175);
        dovakinNumber.setLayoutY(macroY + 70);
        walls.setX(macroX);
        walls.setY(macroY);
        walls.setFill(Color.TRANSPARENT);
        walls.setStroke(Color.DARKORANGE);
        entrance.setX(macroX + 90);
        entrance.setY(macroY + 120);
        entrance.setFill(Color.TRANSPARENT);
        entrance.setStroke(Color.TRANSPARENT);
        tombBounds.setX(macroX - 100);
        tombBounds.setY(macroY + 40);
        tombBounds.setFill(Color.TRANSPARENT);
        tombBounds.setStroke(Color.TRANSPARENT);
        MacroCompositionStage.setScene(MacroCompositionScene);
        tombListView = new ListView<>();
        exitButton.setLayoutX(280);
        exitButton.setLayoutY(90);
        MacroCompositionGroup.getChildren().addAll(tombListView, exitButton);
        HelloApplication.group.getChildren().addAll(walls, tombView, name, entrance, tombBounds, dovakinNumber);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tombListView.setItems(dovakinsInMacroobjects);
        index = tombListView.getSelectionModel().getSelectedIndex();
    }
    @Override
    public void composition (MouseEvent event) {
        if (tombView.boundsInParentProperty().get().contains(HelloApplication.trueMouseX,
                HelloApplication.trueMouseY)) {
            tombListView.setItems(dovakinsInMacroobjects);
            MacroCompositionStage.show();
        }
        exitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    exit();
                } catch (IndexOutOfBoundsException e) {
                    System.out.println(e.getMessage());
                }
            }
        });
    }
    public void exit() {
        System.out.println("DOVAKIN " + dovakinsInMacroobjects.get(index) + " HAS_LEFT_THE_MACROOBJECT");
        System.out.println(index);
        System.out.println(dovakinsInMacroobjects.get(index));
        Dovakin exittingDovakin = dovakinsInMacroobjects.remove(index);
        exittingDovakin.dragonShouts.add(new FusRoDah());
        exittingDovakin.setDovakinX(macroX - 80);
        exittingDovakin.setDovakinY(macroY + 40);
        exittingDovakin.moveImage(exittingDovakin.getDovakinX(), exittingDovakin.getDovakinY());
        exittingDovakin.appear();
        dovakinNumber.setText(Integer.toString(dovakinsInMacroobjects.size()));
    }

    public ListView<Dovakin> getTombListView() {
        return tombListView;
    }

    public void setTombListView(ListView<Dovakin> tombListView) {
        this.tombListView = tombListView;
    }

    public Label getName() {
        return name;
    }

    public void setName(Label name) {
        this.name = name;
    }

    public Image getTomb() {
        return tomb;
    }

    public void setTomb(Image tomb) {
        this.tomb = tomb;
    }

    public Rectangle getWalls() {
        return walls;
    }

    public void setWalls(Rectangle walls) {
        this.walls = walls;
    }

    public Rectangle getEntrance() {
        return entrance;
    }

    public void setEntrance(Rectangle entrance) {
        this.entrance = entrance;
    }

    public Rectangle getTombBounds() {
        return tombBounds;
    }

    public void setTombBounds(Rectangle tombBounds) {
        this.tombBounds = tombBounds;
    }
}
