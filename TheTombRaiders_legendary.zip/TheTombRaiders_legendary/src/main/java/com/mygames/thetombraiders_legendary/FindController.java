package com.mygames.thetombraiders_legendary;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.Collections;
import java.util.ResourceBundle;

import static com.mygames.thetombraiders_legendary.HelloApplication.team;

public class FindController implements Initializable {
    @FXML
    TextField nameToFind;
    @FXML
    TextField lvlToFind;
    @FXML
    TextField hpToFind;
    @FXML
    ListView<Dovakin> searchedListView = new ListView<>();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        searchedListView.setItems(team);
        searchedListView.refresh();
    }
    public void search() {
        ObservableList <Dovakin> searchedList = FXCollections.observableArrayList();
        if (lvlToFind.getText().equals("") && hpToFind.getText().equals("")) {
            for (Dovakin d: team) {
                if (nameToFind.getText().equals(d.getName())) {
                    searchedList.add(d);
                }
            }
            searchedListView.setItems(searchedList);
            searchedListView.refresh();
        } if (!nameToFind.getText().equals("") && !lvlToFind.getText().equals("") && !hpToFind.getText().equals("")) {
            Dovakin tmp = new Dovakin(nameToFind.getText(), Integer.parseInt(lvlToFind.getText()), Double.parseDouble(hpToFind.getText()), 100, 100);
            Collections.sort(searchedList, (d1, d2) -> d1.getName().compareTo(d2.getName()));
            int index = Collections.binarySearch(team, tmp);
            searchedList.add(team.get(index));
            searchedListView.setItems(searchedList);
            searchedListView.refresh();
        } if (nameToFind.getText().equals("") && lvlToFind.getText().equals("") && hpToFind.getText().equals("")) {

            searchedListView.setItems(team);
            searchedListView.refresh();
        }
    }
}
