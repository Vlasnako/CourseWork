package com.mygames.thetombraiders_legendary;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.effect.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.TriangleMesh;
import javafx.scene.text.Font;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public class Dovakin implements Serializable, Comparable<Dovakin>, Cloneable {
    static{
        activeDovakinList = FXCollections.observableArrayList();
    }
    Image dovakin = new Image(Dovakin.class.getResource("Experienced.png").toString(), 40, 70, false, false);
    List<Image> images = new ArrayList<>();

    private String hierarchy;
    private Rectangle rectangle;
    private String name;
    private Integer lvl;
    private Double health;
    private double dovakinX, dovakinY;
    private boolean seen = false;
    private boolean active = false;
    public static ObservableList <Dovakin> activeDovakinList;
    private List <DragonShout> dragonShouts = new ArrayList<>();
    Label showName;
    Label showLvl;
    Line hP;

    ImageView dovakinView = new ImageView(dovakin);
    {
        System.out.println("Init");
    }

    public String getHierarchy() {
        return hierarchy;
    }

    public void setHierarchy(String hierarchy) {
        this.hierarchy = hierarchy;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getLvl() {
        return lvl;
    }
    public void setLvl(int lvl) {
        if (lvl <= 100 && lvl > 0) {
            this.lvl = lvl;
        } else if (lvl < 0) {
            this.lvl = 1;
        } else this.lvl = 100;
    }
    public double getHealth() {
        return health;
    }
    public void setHealth(double health) {
        if (health <= 100 && health > 0) {
            this.health = health;
        } else if (health < 0) {
            this.health = (double)1;
        } else this.health = (double)100;
    }
    public void setDovakinX(double dovakinX) {
        this.dovakinX = dovakinX;
    }
    public double getDovakinX() {
        return dovakinX;
    }
    public void setDovakinY(double dovakinY) {
        this.dovakinY = dovakinY;
    }
    public double getDovakinY() {
        return dovakinY;
    }
    public void setHpLabel (Double hP) {
        this.hP.setEndX(this.hP.getStartX()+health*0.5);
    }
    public void setNameLabel (String name) {
        this.showName.setText(name);
    }
    public void setLvlLabel (Integer lvl) {
        this.showLvl.setText(lvl.toString());
    }

    // EQUALS

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        } else
        if(o instanceof Dovakin) {
            return ((Dovakin) o).name == name &&
                    ((Dovakin) o).health == health &&
                    ((Dovakin) o).lvl == lvl;
        } else return false;
    }

    // TO STRING

    @Override
    public String toString() {
        return "Dovakin" + "{ Name: "+name+"; Health: "+health+"; lvl: "+lvl + "}"+ "COORDS: "+ dovakinX+";" + dovakinY;
    }

    // COMPARE TO

    @Override
    public int compareTo(Dovakin anotherDovakin) {
        return this.name.compareTo(anotherDovakin.name);
    }

    // HASH CODE

    @Override
    public int hashCode() {
        return Objects.hash(hierarchy, name, lvl);
    }

    //  CLONE

    @Override
    public Dovakin clone() {
        Dovakin clonedDovakin = new Dovakin("Clone of " + getName(), getLvl(), getHealth(), AddDovakinMenu.spawnPointX, AddDovakinMenu.spawnPointY);
        List <DragonShout> clonedDragonShoutList = new ArrayList<>(this.dragonShouts);
        clonedDovakin.dragonShouts = clonedDragonShoutList;
        AddDovakinMenu.spawnPointX += 40;
        return clonedDovakin;
    }

    // COMPARATORS

    static class NameComparator implements Comparator<Dovakin> {
        @Override
        public int compare(Dovakin dovakin1, Dovakin dovakin2) {
            return dovakin1.getName().compareTo(dovakin2.getName());
        }
    }

    static class LevelComparator implements Comparator <Dovakin> {
        @Override
        public int compare(Dovakin dovakin1, Dovakin dovakin2) {
            return dovakin1.getLvl()-dovakin2.getLvl();
        }
    }

    static class healthComparator implements Comparator <Dovakin> {
        @Override
        public int compare(Dovakin dovakin1, Dovakin dovakin2) {
            return (int)((int) dovakin1.getHealth()-dovakin2.getHealth());
        }
    }

    // CONSTRUCTORS

    public Dovakin(String name,int lvl,double health, double x, double y ) {
        hierarchy = "Dovakin";
        this.name = name;
        setHealth(health);
        setLvl(lvl);
        this.dovakinX = x;
        this.dovakinY = y;
        rectangle = new Rectangle(55, 75);
        rectangle.setFill(Color.TRANSPARENT);
        rectangle.setStroke(Color.RED);
        rectangle.setX(dovakinX);
        rectangle.setY(dovakinY);
        System.out.println("Complete constructor summoned");
        images.add(dovakin);
        showName = new Label(name);
        showLvl = new Label(Integer.toString(lvl));
        dovakinView.setImage(images.get(0));
        showName.setLayoutX(dovakinX);
        showName.setLayoutY(dovakinY-30);
        hP = new Line();
        hP.setStroke(Color.LIGHTGREEN);
        hP.setStrokeWidth(5);
        showName.setFont(Font.font("Garamond", 10));
        hP.setStartX(dovakinX-15);
        hP.setEndX(hP.getStartX()+health*0.5);
        hP.setStartY(dovakinY-20);
        hP.setEndY(dovakinY-20);
        dovakinView.setX(dovakinX-5);
        dovakinView.setY(dovakinY-5);
      //  dovakinView.setEffect(colorAdjust);
        rectangle.setX(dovakinX-5);
        rectangle.setY(dovakinY-10);
        showLvl.setLayoutX(dovakinX-10);
        showLvl.setLayoutY(dovakinY-10);
    }
    public Dovakin() {
        this("Player", 1, 80, 100, 100);
        System.out.println("Default constructor summoned"); System.out.println(getName());
        System.out.println(this);
    }

    //METHODS

    public void moveImage(double dovakinX, double dovakinY) {
        hP.setStartX(dovakinX-15);
        hP.setEndX(hP.getStartX() + health * 0.5);
        hP.setStartY(dovakinY-20);
        hP.setEndY(dovakinY-20);
        showName.setLayoutX(dovakinX);
        showName.setLayoutY(dovakinY-30);
        dovakinView.setX(dovakinX-5);
        dovakinView.setY(dovakinY-5);
        showLvl.setLayoutX(dovakinX-10);
        showLvl.setLayoutY(dovakinY-10);
        rectangle.setX(dovakinX - 5);
        rectangle.setY(dovakinY - 10);

        System.out.println("X_LAYOUT_DOVAKIN: " + dovakinView.getX() + " ||| Y_LAYOUT_DOVAKIN: " + dovakinView.getY());
    }

    public void walk(KeyEvent event) {
        if(event.getCode().equals(KeyCode.UP)) {
            dovakinY -= 2;
            moveImage(dovakinX, dovakinY);
        }
        if(event.getCode().equals(KeyCode.DOWN)) {
            dovakinY += 2;
            moveImage(dovakinX, dovakinY);
        }
        if(event.getCode().equals(KeyCode.RIGHT)) {
            dovakinX += 2;
            moveImage(dovakinX, dovakinY);
        }
        if(event.getCode().equals(KeyCode.LEFT)) {
            dovakinX -= 2;
            moveImage(dovakinX, dovakinY);
        }
    }

    public boolean isActive() {
        return active;
    }
    public boolean flipActivation(){
        if(active){
            //dovakinView.setEffect(colorAdjust);
            HelloApplication.group.getChildren().remove(rectangle);
            activeDovakinList.remove(this);
        }
        else{
           // dovakinView.setEffect(activeColorAdjust);
            HelloApplication.group.getChildren().add(rectangle);
            activeDovakinList.add(this);
        }
        active= !active;

        return active;
    }

    public boolean mouseActivate( double mx, double my ){
        if(dovakinView.boundsInParentProperty().get().contains(mx,my)){
            flipActivation();
            return true;
        }
        return false;
    }

    public void die() {
        if(health <= 0) {
            HelloApplication.team.remove(this);
            disappear();
        }
    }

    public void remove() {
        HelloApplication.team.remove(this);
        disappear();
    }

//    public void run(KeyEvent keyEvent) {
//        seen = true;
//
//        if(keyEvent.getCode().equals(KeyCode.UP)) {
//            dovakinY -= 5;
//            dovakinView.setEffect(motionBlur);
//            moveImage(dovakinX, dovakinY);
//        }
//        if(keyEvent.getCode().equals(KeyCode.DOWN)) {
//            dovakinY += 5;
//            dovakinView.setEffect(motionBlur);
//            moveImage(dovakinX, dovakinY);
//        }
//        if(keyEvent.getCode().equals(KeyCode.RIGHT)) {
//            dovakinX += 5;
//            dovakinView.setEffect(motionBlur);
//            moveImage(dovakinX, dovakinY);
//        }
//        if(keyEvent.getCode().equals(KeyCode.LEFT)) {
//            dovakinX -= 5;
//            dovakinView.setEffect(motionBlur);
//            moveImage(dovakinX, dovakinY);
//        }
//    }

    public void sneak() {
        seen = false;
    }

    public void appear() {
        System.out.println("APPEARED");
        HelloApplication.group.getChildren().addAll( dovakinView, showLvl, hP, showName);
    }

    public void disappear() {
        flipActivation();
        HelloApplication.group.getChildren().removeAll(dovakinView, showLvl, showName, hP);
    }

    public void disappearWithoutFlip() {
        HelloApplication.group.getChildren().removeAll(dovakinView, showLvl, showName, hP, rectangle);
    }
}