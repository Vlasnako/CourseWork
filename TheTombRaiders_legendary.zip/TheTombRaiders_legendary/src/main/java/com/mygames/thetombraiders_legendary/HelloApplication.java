package com.mygames.thetombraiders_legendary;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ConcurrentModificationException;
public class HelloApplication extends Application{
    static Group group;
    static Scene scene;
    static Stage window;
    static Stage findByGivenParamsStage;
    static Scene findByGivenParamsScene;
    Stage addDov = new Stage();
    @FXML
    public  static ObservableList<Dovakin> team = FXCollections.observableArrayList();
    private Parent load;

    @Override
    public void start(Stage stage) throws Exception {
        try {
            Image icon = new Image(HelloApplication.class.getResource("Icon46.png").toString());
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("menuFile.fxml"));
            FXMLLoader findByGivenParamsLoader = new FXMLLoader(HelloApplication.class.getResource("findFile.fxml"));
//            BackgroundImage myBI= new BackgroundImage(new Image("my url",32,32,false,true),
//                    BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
//                    BackgroundSize.DEFAULT);

            HelloApplication.window = stage;
            findByGivenParamsStage = new Stage();
            group = new Group();
            scene = new Scene(group, 1470, 770);
            findByGivenParamsScene = new Scene(findByGivenParamsLoader.load());
            window.setResizable(false);
            window.setTitle("TheTombRaiders");
            window.getIcons().add(icon);
            Scene sceneMenu = new Scene(fxmlLoader.load());
            window.setScene(scene);
            findByGivenParamsStage.setScene(findByGivenParamsScene);
            window.show();
            Tomb tomb = new Tomb(330, 400);
            DragonRoom dragonRoom= new DragonRoom(100, 100);
            TreasureRoom treasureRoom = new TreasureRoom(600, 200);
            AddDovakinMenu addDovakinMenu = new AddDovakinMenu();
            scene.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    if(event.getButton().equals(MouseButton.PRIMARY)) {
                        boolean flg=false;
                        for( Dovakin d: team ){
                            if( d.mouseActivate(event.getX(), event.getY())) {
                                flg=true;
                            }
                        }
                        if (!flg) {
                            System.out.println(event.getX() + "||||" + event.getY()
                            );

                        }
                    } else {
                        tomb.composition(event);
                        treasureRoom.composition(event);
                        dragonRoom.composition(event);
                    }
                }
            });
            scene.addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
                final KeyCombination keyCombinationFinding = new KeyCodeCombination(KeyCode.F , KeyCombination.CONTROL_DOWN);
                final KeyCombination keyCombinationUp = new KeyCodeCombination(KeyCode.UP , KeyCombination.CONTROL_DOWN);
                final KeyCombination keyCombinationDown = new KeyCodeCombination(KeyCode.DOWN , KeyCombination.CONTROL_DOWN);

                final KeyCombination keyCombinationRight = new KeyCodeCombination(KeyCode.RIGHT , KeyCombination.CONTROL_DOWN);

                final KeyCombination keyCombinationLeft = new KeyCodeCombination(KeyCode.LEFT , KeyCombination.CONTROL_DOWN);

                @Override
                public void handle(KeyEvent keyEvent) {
                    if (keyCombinationUp.match(keyEvent)||keyCombinationDown.match(keyEvent)||keyCombinationRight.match(keyEvent)||keyCombinationLeft.match(keyEvent) ) {
                        for (Dovakin d : team) {
                            if (d.isActive()) {
                               if (tomb.tombView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                                   System.out.println("++++++");
                                   tomb.dovakinsInMacroobjects.add(d);
                                   d.disappear();
                               }
                               // d.run(keyEvent);
                            }
                        }
                    }
                    if (keyCombinationFinding.match(keyEvent)) {
                        FindController findController = new FindController();
                        findController.searchedListView.setItems(team);
                        findByGivenParamsStage.show();
                    }
                    if(keyEvent.getCode().equals(KeyCode.INSERT)) {
                        addDov.setScene(sceneMenu);
                        addDov.show();
                    }
                    if(keyEvent.getCode().isArrowKey()) {
                        try {
                            for (Dovakin d : Dovakin.activeDovakinList) {
                                if (tomb.tombView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                                    tomb.acceptDovakin(d);
                                }
                                if (treasureRoom.treasureRoomView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                                    treasureRoom.acceptDovakin(d);
                                }
                                if (dragonRoom.dragonRoomView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                                    dragonRoom.acceptDovakin(d);
                                }
                                d.walk(keyEvent);
                            }
                        } catch (ConcurrentModificationException e) {
                            System.out.println(e.getMessage());
                        }
                    }

                    if(keyEvent.getCode().equals(KeyCode.ESCAPE)) {
                        for(Dovakin d: team) {
                            if (d.isActive()) {
                                d.flipActivation();
                            }
                        }
                    }
                    if (keyEvent.getCode().equals(KeyCode.DELETE)) {
                        try {
                            team.removeIf(d -> {if (d.isActive()) d.disappearWithoutFlip();return d.isActive();});

                        } catch (ConcurrentModificationException e) {
                            System.out.println("The team is empty - " + e.getMessage());
                        }
                    }
                    if (keyEvent.getCode().equals(KeyCode.C)) {
                        for (Dovakin d: Dovakin.activeDovakinList) {
                           Dovakin cloned = d.clone();
                           team.add(cloned);
                           cloned.appear();
                        }
                    }

                }
            });

        } catch (IOException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }
        public static void main (String[]args){
            Application.launch(args);
        }
}
