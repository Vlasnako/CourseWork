package com.mygames.thetombraiders_legendary;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ConcurrentModificationException;
public class HelloApplication extends Application{
    static int activeDovakinsNumber;
    static int totalNumberOfDovakins;
    static Label activeDovakinsNumberLabel;
    static Label totalNumberOfDovakinsLabel;
    static Group group;
    static Scene scene;
    static Stage window;
    static Stage findByGivenParamsStage;
    static Scene findByGivenParamsScene;
    Stage addDov = new Stage();
    @FXML
    public  static ObservableList<Dovakin> team = FXCollections.observableArrayList();

    @Override
    public void start(Stage stage) throws Exception {
        try {
            Image icon = new Image(HelloApplication.class.getResource("Icon46.png").toString());

            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("menuFile.fxml"));
            FXMLLoader findByGivenParamsLoader = new FXMLLoader(HelloApplication.class.getResource("findFile.fxml"));

            HelloApplication.window = stage;
            findByGivenParamsStage = new Stage();

            group = new Group();
            scene = new Scene(group, 1470, 770);

            activeDovakinsNumberLabel = new Label("Number of active dovakins: " + activeDovakinsNumber);
            activeDovakinsNumberLabel.setLayoutX(10);
            activeDovakinsNumberLabel.setLayoutY(10);

            totalNumberOfDovakinsLabel = new Label("Total number of dovakins: " + totalNumberOfDovakins);
            totalNumberOfDovakinsLabel.setLayoutX(10);
            totalNumberOfDovakinsLabel.setLayoutY(30);

            group.getChildren().addAll(activeDovakinsNumberLabel, totalNumberOfDovakinsLabel);

            findByGivenParamsScene = new Scene(findByGivenParamsLoader.load());

            window.setResizable(false);
            window.setTitle("TheTombRaiders");
            window.getIcons().add(icon);

            Scene sceneMenu = new Scene(fxmlLoader.load());

            window.setScene(scene);

            findByGivenParamsStage.setScene(findByGivenParamsScene);

            window.show();

            Tomb tomb = new Tomb(330, 400);
            DragonRoom dragonRoom= new DragonRoom(100, 100);
            TreasureRoom treasureRoom = new TreasureRoom(900, 200);

            AddDovakinMenu addDovakinMenu = new AddDovakinMenu();

            scene.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    if(event.getButton().equals(MouseButton.PRIMARY)) {
                        boolean flg=false;
                        for( Dovakin d: team ){
                            if( d.mouseActivate(event.getX(), event.getY())) {
                                flg=true;
                            }
                        }
                        if (!flg) {
                            System.out.println(event.getX() + "||||" + event.getY()
                            );

                        }
                    } else {
                        tomb.composition(event);
                        treasureRoom.composition(event);
                        dragonRoom.composition(event);
                    }
                }
            });
            scene.addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
                final KeyCombination keyCombinationFinding = new KeyCodeCombination(KeyCode.F , KeyCombination.CONTROL_DOWN);

                @Override
                public void handle(KeyEvent keyEvent) {

                    if (keyCombinationFinding.match(keyEvent)) {
                        FindController findController = new FindController();
                        findController.searchedListView.setItems(team);
                        findByGivenParamsStage.show();
                    }
                    if(keyEvent.getCode().equals(KeyCode.INSERT)) {
                        addDov.setScene(sceneMenu);
                        addDov.show();
                    }
                    if(keyEvent.getCode().isArrowKey()) {
                        try {
                            for (Dovakin d : Dovakin.activeDovakinList) {
                                if (tomb.tombView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                                    tomb.acceptDovakin(d);
                                }
                                if (treasureRoom.treasureRoomView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                                    treasureRoom.acceptDovakin(d);
                                }
                                if (dragonRoom.dragonRoomView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                                    dragonRoom.acceptDovakin(d);
                                }
                                d.walk(keyEvent);
                            }
                        } catch (ConcurrentModificationException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    if(keyEvent.getCode().equals(KeyCode.ESCAPE)) {
                        for(Dovakin d: team) {
                            if (d.isActive()) {
                                d.flipActivation();
                            }
                        }
                        setToZeroActiveDovakinCountAndSetLabel();
                    }
                    if (keyEvent.getCode().equals(KeyCode.DELETE)) {
                        try {
                            team.removeIf(d -> {if (d.isActive()) d.disappearWithoutFlip();
                                setDovakinCountAndSetLabel();
                                return d.isActive();
                            });
                        } catch (ConcurrentModificationException e) {
                            System.out.println("The team is empty - " + e.getMessage());
                        }
                    }
                    if (keyEvent.getCode().equals(KeyCode.C)) {
                        for (Dovakin d: Dovakin.activeDovakinList) {
                           Dovakin cloned = d.clone();
                           team.add(cloned);
                           cloned.appear();
                        }
                    }

                }
            });

        } catch (IOException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }

    }

    public static void setActiveDovakinCountAndSetLabel() {
        activeDovakinsNumber = Dovakin.activeDovakinList.size();
        activeDovakinsNumberLabel.setText("Number of active dovakins: " + activeDovakinsNumber);
    }
    public static void setToZeroActiveDovakinCountAndSetLabel() {
        activeDovakinsNumber = 0;
        activeDovakinsNumberLabel.setText("Total number of dovakins: " + totalNumberOfDovakins);
    }
    public static void setDovakinCountAndSetLabel() {
        totalNumberOfDovakins = team.size();
        totalNumberOfDovakinsLabel.setText("Total number of dovakins: " + totalNumberOfDovakins);
    }
        public static void main (String[]args){
            Application.launch(args);
        }
}
