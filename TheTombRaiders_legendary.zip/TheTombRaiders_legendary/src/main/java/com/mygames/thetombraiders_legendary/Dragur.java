package com.mygames.thetombraiders_legendary;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

import java.util.ArrayList;
import java.util.List;

public class Dragur {
    public static List<Dragur> dragurs = new ArrayList<>();
    private final int damage = 20;
    private int health;
    Image dragur = new Image(Dragur.class.getResource("dragur.png").toString());
    ImageView dragurView;
    protected byte autoWalk;
    protected final int speed = 1;
    protected double dragurX, dragurY;
    protected Line healthLine;
    public void moveImage(double dragurX, double dragurY) {

        healthLine.setStartX(dragurX-8);
        healthLine.setEndX(healthLine.getStartX() + health * 0.6);
        healthLine.setStartY(dragurY-20);
        healthLine.setEndY(dragurY-20);

        dragurView.setX(dragurX-5);
        dragurView.setY(dragurY-15);
    }
    public void takeDamage(int damage) {
        health -= damage;
        if (health <= 0) {
            die();
        }
        healthLine.setEndX(healthLine.getStartX() + health * 0.6);
    }
    public void die() {
        HelloApplication.group.getChildren().removeAll( dragurView, healthLine);
    }

    public Dragur(double dragurX, double dragurY) {
        this.dragurX = dragurX;
        this.dragurY = dragurY;
        this.health = 100;
        dragurView = new ImageView(dragur);
        healthLine = new Line();
        healthLine.setStroke(Color.RED);
        healthLine.setStartX(this.dragurX-8);
        healthLine.setEndX(healthLine.getStartX() + health * 0.6);
        healthLine.setStartY(this.dragurY-20);
        healthLine.setEndY(this.dragurY-20);

        dragurView.setX(this.dragurX-5);
        dragurView.setY(this.dragurY-15);
    }
    public static void addDragur() {
        Dragur dragur = new Dragur(1000, 1000);
        dragurs.add(dragur);
        dragur.appear();
    }
    public void appear() {
        System.out.println("APPEARED");
        HelloApplication.group.getChildren().addAll( dragurView, healthLine);
    }
    public void autoWalk() {
            switch (this.autoWalk) {
                case 0:
                    dragurY -= this.speed;
                    break;
                case 1:
                    dragurY -= this.speed;
                    dragurX += this.speed;
                    break;
                case 2:
                    dragurX += this.speed;
                    break;
                case 3:
                    dragurX += this.speed;
                    dragurY += this.speed;
                    break;
                case 4:
                    dragurY += this.speed;
                    break;
                case 5:
                    dragurY += this.speed;
                    dragurX -= this.speed;
                    break;
                case 6:
                    dragurX -= this.speed;
                    break;
                case 7:
                    dragurX -= this.speed;
                    dragurY -= this.speed;
                    break;
            }
            if (this.dragurView.getX() + this.dragurView.getFitWidth() + 100 >= (HelloApplication.getRootWidth() - 100) - this.dragurView.getFitWidth()) {
                this.autoWalk = (byte) (HelloApplication.random.nextInt(3) + 5);
            } else if (this.dragurView.getX() <= 0) {
                this.autoWalk = (byte) (HelloApplication.random.nextInt(3) + 1);
            } else if (this.dragurView.getY() <= 0) {
                this.autoWalk = (byte) (HelloApplication.random.nextInt(3) + 3);
            } else if (this.dragurView.getY() + this.dragurView.getFitHeight() >= (HelloApplication.getRootHeight() - 100)) {
                this.autoWalk = (byte) (HelloApplication.random.nextInt(2));
            }
            moveImage(dragurX, dragurY);
        }
}
