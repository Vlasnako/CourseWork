package com.mygames.thetombraiders_legendary;

import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;

import java.util.ArrayList;
import java.util.List;

public class DovakinMage extends Dovakin{
    private Image dovakin = new Image(Dovakin.class.getResource("Attack_1.png").toString(), 55, 100, false, false);

    protected int magicianSkillsStrength;
    protected List<Magic> dovakinMageMagicList;

    public DovakinMage(String dovakinName, int dovakinLevel, double dovakinHealth, int magicianSkillsStrength, double x, double y ) {
        hierarchyOfDovakins = "DovakinMage";
        this.dovakinName = dovakinName;

        this.magicianSkillsStrength = magicianSkillsStrength;

        dovakinMageMagicList = new ArrayList<>();
        dragonShouts = new ArrayList<>();

        setDovakinHealth(dovakinHealth);
        setDovakinLevel(dovakinLevel);

        this.dovakinX = x;
        this.dovakinY = y;

        activeDovakinRectangle = new Rectangle(65, 95);
        activeDovakinRectangle.setFill(Color.TRANSPARENT);
        activeDovakinRectangle.setStroke(Color.RED);

        System.out.println("Complete constructor summoned");

        dovakinNameLabel = new Label(dovakinName);

        dovakinLevelLabel = new Label(Integer.toString(getDovakinLevel()));

        dovakinView.setImage(dovakin);

        dovakinNameLabel.setLayoutX(dovakinX + 10);
        dovakinNameLabel.setLayoutY(dovakinY-40);

        healthLine = new Line();
        healthLine.setStroke(Color.LIGHTGREEN);
        healthLine.setStrokeWidth(5);

        dovakinNameLabel.setFont(Font.font("Garamond", 10));

        healthLine.setStartX(dovakinX-8);
        healthLine.setEndX(healthLine.getStartX()+ getDovakinHealth()*0.6);
        healthLine.setStartY(dovakinY-20);
        healthLine.setEndY(dovakinY-20);

        dovakinView.setX(dovakinX-5);
        dovakinView.setY(dovakinY-15);

        activeDovakinRectangle.setX(dovakinX-10);
        activeDovakinRectangle.setY(dovakinY-10);

        dovakinLevelLabel.setLayoutX(dovakinX-10);
        dovakinLevelLabel.setLayoutY(dovakinY-10);
    }
    public DovakinMage() {
        this("Player", 1, 80, 1, 100, 100);
        System.out.println("Default constructor summoned");
        System.out.println(getDovakinName());
        System.out.println(this);
    }

    public int getMagicianSkillsStrength() {
        return magicianSkillsStrength;
    }

    public void setMagicianSkillsStrength(int magicianSkillsStrength) {
        this.magicianSkillsStrength = magicianSkillsStrength;
    }

    @Override
    public String toString() {
        return "DovakinMage{" +
                "magicianSkillsStrength=" + magicianSkillsStrength +
                ", hierarchyOfDovakins='" + hierarchyOfDovakins + '\'' +
                ", dovakinName='" + dovakinName + '\'' +
                ", dovakinLevel=" + dovakinLevel +
                ", dovakinHealth=" + dovakinHealth +
                ", dovakinX=" + dovakinX +
                ", dovakinY=" + dovakinY +
                '}';
    }

    public void magicAttack() {

    }
}
