package com.mygames.thetombraiders_legendary;

import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

public class ExperiencedDovakin extends DovakinMage{
    private Image dovakin = new Image(Dovakin.class.getResource("Experienced.png").toString(), 55, 100, false, false);
    private int experience;

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    @Override
    public Dovakin clone() {
        Dovakin clonedDovakin = new ExperiencedDovakin("Clone of " + getDovakinName(), getDovakinLevel(), getDovakinHealth(), getMagicianSkillsStrength(), getExperience(), dovakinX + 50, dovakinY);
        List <DragonShout> clonedDragonShoutList = new ArrayList<>(this.dragonShouts);
        clonedDovakin.dragonShouts = clonedDragonShoutList;

        clonedDovakin.setDovakinView(new ImageView(new Image(HelloApplication.class.getResource("Fireball.png").toString(), 55, 90, false, false)));
        clonedDovakin.getDovakinView().setX(clonedDovakin.dovakinX - 5);
        clonedDovakin.getDovakinView().setY(clonedDovakin.dovakinY - 5);

        HelloApplication.setDovakinCountAndSetLabel();

        return clonedDovakin;
    }
    

    public ExperiencedDovakin(String dovakinName, int dovakinLevel, double dovakinHealth, int magicianSkillsStrength, int experience, double x, double y ) {
        hierarchyOfDovakins = "ExperiencedDovakin";
        this.dovakinName = dovakinName;

        this.magicianSkillsStrength = magicianSkillsStrength;

        dovakinMageMagicList = new ArrayList<>();
        dragonShouts = new ArrayList<>();

        setDovakinHealth(dovakinHealth);
        setDovakinLevel(dovakinLevel);

        this.dovakinX = x;
        this.dovakinY = y;

        activeDovakinRectangle = new Rectangle(65, 95);
        activeDovakinRectangle.setFill(Color.TRANSPARENT);
        activeDovakinRectangle.setStroke(Color.RED);

        System.out.println("Complete constructor summoned");

        dovakinNameLabel = new Label(dovakinName);

        dovakinLevelLabel = new Label(Integer.toString(getDovakinLevel()));

        dovakinView.setImage(dovakin);

        dovakinNameLabel.setLayoutX(dovakinX + 10);
        dovakinNameLabel.setLayoutY(dovakinY-40);

        healthLine = new Line();
        healthLine.setStroke(Color.LIGHTGREEN);
        healthLine.setStrokeWidth(5);

        dovakinNameLabel.setFont(Font.font("Garamond", 10));

        healthLine.setStartX(dovakinX-8);
        healthLine.setEndX(healthLine.getStartX()+ getDovakinHealth()*0.6);
        healthLine.setStartY(dovakinY-20);
        healthLine.setEndY(dovakinY-20);

        dovakinView.setX(dovakinX-5);
        dovakinView.setY(dovakinY-15);

        activeDovakinRectangle.setX(dovakinX-10);
        activeDovakinRectangle.setY(dovakinY-10);

        dovakinLevelLabel.setLayoutX(dovakinX-10);
        dovakinLevelLabel.setLayoutY(dovakinY-10);
    }
    public ExperiencedDovakin() {
        this("Player", 50, 100, 10, 10, 100, 100);
        System.out.println("Default constructor summoned");
        System.out.println(getDovakinName());
        System.out.println(this);
    }
}
