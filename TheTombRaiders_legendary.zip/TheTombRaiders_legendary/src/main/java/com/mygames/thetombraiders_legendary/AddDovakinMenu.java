package com.mygames.thetombraiders_legendary;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.Collections;
import java.util.Comparator;
import java.util.ResourceBundle;
import java.util.function.Consumer;

import static com.mygames.thetombraiders_legendary.HelloApplication.*;
public class AddDovakinMenu implements Initializable {
    private static int index;
    static double spawnPointX = 565, spawnPointY = 710;
    @FXML
    CheckBox enableCloneDovakin;
    @FXML
    TextField nameTextField;
    @FXML
    TextField lvlTextField;
    @FXML
    TextField hpTextField;
    ////////////////////////////////

    ////////////////////////////////
    @FXML
    Label infoLabel = new Label("");
    @FXML
    Label numberFormat = new Label();
    @FXML
    TableView <Dovakin> tableView = new TableView<>();
    @FXML
    TableColumn <Dovakin, String> nameCol;
    @FXML
    TableColumn <Dovakin, Integer> lvlCol;
    @FXML
    TableColumn <Dovakin, Integer> healthCol;
    @FXML
    TableColumn <Dovakin, String> hierarchyCol;
    @FXML
    Button Add = new Button();
    @FXML
    ChoiceBox <String> choiceBox = new ChoiceBox<>();
    @FXML
    RadioButton dovakinRadioButton;
    @FXML
    private TextField xField;
    @FXML
    private TextField yField;
    private boolean isDovakin = false;
    private boolean isDovakinMage = false;
    private boolean isExperiencedDovakin = false;
    @FXML
    RadioButton dovakinMageRadioButton;
    @FXML
    RadioButton experiencedDovakinRadioButton;
    @FXML
    ToggleGroup dovakinChoiceToggleGroup = new ToggleGroup();
    private String [] sortingMethodsChoice = {"By name", "By level", "By health"};
    @FXML
    public void addDovakin() {
        try {
            String name = nameTextField.getText();
            Integer lvl = Integer.parseInt(lvlTextField.getText());
            Double hp = Double.parseDouble(hpTextField.getText());

            numberFormat.setText("");
            if (dovakinRadioButton.isSelected()) {
                if (xField.getText().equals("") || yField.getText().equals("")) {
                    Dovakin temp = new Dovakin(name, lvl, hp, spawnPointX, spawnPointY);
                    spawnPointX += 40;
                    team.add(temp);
                    team.get(team.size() - 1).appear();
                    if (enableCloneDovakin.isSelected()) {
                        Dovakin clonedDovakin = temp.clone();
                        clonedDovakin.setName("CloneOf" + clonedDovakin.getName());
                        team.add(clonedDovakin);
                        System.out.println("ADDED " + temp);
                        team.get(team.size()-1).appear();
                        spawnPointX += 40;
                    }
                } else {
                    double x = Double.parseDouble(xField.getText());
                    double y = Double.parseDouble(yField.getText());
                    Dovakin temp = new Dovakin(name, lvl, hp, x, y);
                    team.add(temp);
                    team.get(team.size() - 1).appear();
                    if (enableCloneDovakin.isSelected()) {
                        Dovakin clonedDovakin = temp.clone();
                        clonedDovakin.setName("CloneOf" + clonedDovakin.getName());
                        team.add(clonedDovakin);
                        System.out.println("ADDED " + temp);
                        team.get(team.size()-1).appear();
                    }
                }


            }
            System.out.println("CURRENT TEAM:");
            for (Dovakin d : team) {
                System.out.println(d);
            }

            nameTextField.clear();
            lvlTextField.clear();
            hpTextField.clear();
        } catch (NumberFormatException e) {
            numberFormat.setText("Wrong data format entered!");
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        choiceBox.getItems().addAll(sortingMethodsChoice);
        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                index = tableView.getSelectionModel().getSelectedIndex();
                infoLabel.setText(team.get(index).toString());
            }
        });

        tableView.getSelectionModel().selectedItemProperty().addListener(((observableValue, dovakin, t1) -> tableView.setItems(team)));
        nameCol.setCellValueFactory(new PropertyValueFactory<Dovakin, String>("name"));
        lvlCol.setCellValueFactory(new PropertyValueFactory<Dovakin, Integer>("lvl"));
        healthCol.setCellValueFactory(new PropertyValueFactory<Dovakin, Integer>("health"));
        hierarchyCol.setCellValueFactory(new PropertyValueFactory<Dovakin, String>("hierarchy"));
        tableView.setItems(team);

    }
    @FXML
    public void changeValues() {
        try {
            changeDovakinParams(team.get(index),
                    d -> {d.setName(nameTextField.getText());
                d.setLvl(Integer.parseInt(lvlTextField.getText()));
                d.setHealth(Double.parseDouble(hpTextField.getText()));
                d.setNameLabel(nameTextField.getText());
                d.setLvlLabel(Integer.parseInt(lvlTextField.getText()));
                d.setHpLabel(Double.parseDouble(hpTextField.getText()));
                d.setDovakinX(Double.parseDouble(xField.getText()));
                d.setDovakinY(Double.parseDouble(yField.getText()));
                d.moveImage(Double.parseDouble(xField.getText()), Double.parseDouble(yField.getText()));
            });
            tableView.refresh();
            numberFormat.setText("");
            nameTextField.clear();
            lvlTextField.clear();
            hpTextField.clear();
        } catch (Exception e) {
            numberFormat.setText("Wrong data format entered!");
            System.out.println(e.getMessage());
        }
    }
    @FXML
    public void sortTeam() {

            choiceBox.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    if (choiceBox.getSelectionModel().getSelectedIndex() == 0) {
                        Collections.sort(team, new Comparator<Dovakin>() {
                            @Override
                            public int compare(Dovakin o1, Dovakin o2) {
                                System.out.println("SORTED BY NAME");
                                return o1.getName().compareTo(o2.getName());
                            }
                        });
                    } else if (choiceBox.getSelectionModel().getSelectedIndex() == 1) {
                        Collections.sort(team, (d1, d2) -> d1.getLvl() - d2.getLvl());
                    } else if (choiceBox.getSelectionModel().getSelectedIndex() == 2) {
                        Collections.sort(team, new Dovakin.healthComparator());
                    }
                }
            });

            tableView.refresh();
    }
    @FXML
    public void RemoveFromTeam() {
        try {
            team.get(index).disappear();
            team.remove(index);
        } catch (IndexOutOfBoundsException e) {
            System.out.println("NO info");
        }
    }
    @FXML
    public void cloneThisDovakin() {
            Dovakin clonedDovakin = team.get(index).clone();
            team.add(clonedDovakin);
            team.get(team.size() - 1).appear();
    }
    public static void changeDovakinParams (Dovakin d, Consumer <Dovakin> dovakinConsumer) {
        dovakinConsumer.accept(d);
    }

}