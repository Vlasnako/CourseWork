module com.mygames.thetombraiders_legendary {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.mygames.thetombraiders_legendary to javafx.fxml;
    exports com.mygames.thetombraiders_legendary;
}