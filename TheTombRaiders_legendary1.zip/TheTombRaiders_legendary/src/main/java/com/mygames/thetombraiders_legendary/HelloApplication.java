package com.mygames.thetombraiders_legendary;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Scale;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.Random;

public class HelloApplication extends Application{

    static LocalDateTime beginTime = LocalDateTime.now();
    boolean gflg=false;
    public static ImageView mapView = new ImageView();
    public static Rectangle infoRectangle;
    public static Label infoLabel;
    private static final int rootHeight = 3000;
    private static final int rootWidth = 5000;
    private static double screenDelta=50.0;
    public static double trueMouseX;
    public static double trueMouseY;
    private Rectangle visibleZone;
    private Rectangle miniMapBorder;
    static int frames=0;
    static Group group;
    static Group group2;
    Scale scale;
    private static final double scaleNumber = 0.1;
    // private static ScrollPane scrollPane;
    private static final int sceneWidth = 1920;
    private static final int sceneHeight = 1080;

    private static final int miniMapDeltaX = 1000;
    private static final int miniMapDeltaY = 20;

    static int activeDovakinsNumber;
    static int totalNumberOfDovakins;
    static Label activeDovakinsNumberLabel;
    static Label totalNumberOfDovakinsLabel;
    static Scene scene;
    static Stage window;
    static Stage findByGivenParamsStage;
    static Scene findByGivenParamsScene;
    static Tomb tomb;
    static DragonRoom dragonRoom;
    static TreasureRoom treasureRoom;
    static Dovakin dovakinToChange;
    public static Random random = new Random(new Date().getTime());
    Stage addDov = new Stage();
    @FXML
    public  static ObservableList<Dovakin> team = FXCollections.observableArrayList();

    @Override
    public void start(Stage stage) throws Exception {
        try {

            group = new Group();
            group.setLayoutX(-1 * (rootWidth - sceneWidth));
            group.setLayoutY(-1 * (rootHeight - sceneHeight));

            Rectangle backgroundRectangle = new Rectangle(rootWidth, rootHeight);
            Image img = new Image(HelloApplication.class.getResource("bckg.jpg").toString());
            backgroundRectangle.setFill(new ImagePattern(img));


            activeDovakinsNumberLabel = new Label("Number of active dovakins: " + activeDovakinsNumber);
            activeDovakinsNumberLabel.setLayoutX(10);
            activeDovakinsNumberLabel.setLayoutY(10);

            totalNumberOfDovakinsLabel = new Label("Total number of dovakins: " + totalNumberOfDovakins);
            totalNumberOfDovakinsLabel.setLayoutX(10);
            totalNumberOfDovakinsLabel.setLayoutY(30);

            group.getChildren().addAll(backgroundRectangle, activeDovakinsNumberLabel, totalNumberOfDovakinsLabel);

            tomb = new Tomb(2500, 2000);
            dragonRoom = new DragonRoom(567, 100);
            treasureRoom = new TreasureRoom(1800, 1800);

            Country country = new Country(tomb, treasureRoom, dragonRoom);

            Image icon = new Image(HelloApplication.class.getResource("Icon46.png").toString());

            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("menuFile.fxml"));
            FXMLLoader findByGivenParamsLoader = new FXMLLoader(HelloApplication.class.getResource("findFile.fxml"));

            HelloApplication.window = stage;
            findByGivenParamsStage = new Stage();

            for (int i = 0; i< 10; i++) {
                Dragur.addDragur();
            }


            findByGivenParamsScene = new Scene(findByGivenParamsLoader.load());


            window.setTitle("TheTombRaiders");
            window.getIcons().add(icon);

            Scene sceneMenu = new Scene(fxmlLoader.load());

            window.setMaximized(true);

            group2 = new Group();

            group2.getChildren().add(group);

            scale = new Scale();

            scale.setX(0.1);
            scale.setY(0.1);

            miniMapBorder = new Rectangle(rootWidth * scaleNumber,
                    rootHeight * scaleNumber);
            miniMapBorder.setFill(Color.TRANSPARENT);
            miniMapBorder.setStrokeWidth(3);
            miniMapBorder.setStroke(Color.WHITE);

            group2.getChildren().add(miniMapBorder);

            findByGivenParamsStage.setScene(findByGivenParamsScene);

            AnimationTimer timer = new AnimationTimer() {

                @Override
                public void handle(long now) {
                    for (Dovakin dovakin: team) {

                           dovakin.autoWalk();
                    }
                    for (Dragur dragur: Dragur.dragurs) {
                        dragur.autoWalk();
                    }

                    if( !gflg ) {
                        System.out.println("AnimationTimer.handle() method thread: "
                                + Thread.currentThread().getId());
                        gflg=true;
                    }

                    LocalDateTime nextTime= LocalDateTime.now();
                    if( ChronoUnit.SECONDS.between( beginTime,nextTime)>0 ) {
                        if (mapView != null) {
                            group2.getChildren().remove(mapView);
                        }
                        frames = 0;
                        beginTime = nextTime;

                        final WritableImage SNAPSHOT = group.snapshot(new SnapshotParameters(), null);
                        mapView = new ImageView(SNAPSHOT);
                        mapView.getTransforms().add(scale);
                        group2.getChildren().add(mapView);

                        visibleZone =  new Rectangle(stage.getWidth()* HelloApplication.scaleNumber,
                                stage.getHeight()* HelloApplication.scaleNumber);
                        visibleZone.setFill(Color.TRANSPARENT);
                        visibleZone.setStrokeWidth(2);
                        visibleZone.setStroke(Color.WHITE);

                        double groupX= group.getLayoutX();
                        double groupY = group.getLayoutY();

                        visibleZone.setX((-1.0*groupX)* HelloApplication.scaleNumber);
                        visibleZone.setY((-1.0*groupY)* HelloApplication.scaleNumber);
                        group2.getChildren().add(visibleZone);

                    }
                    else frames++;




                }

            };


            scene = new Scene(group2, sceneWidth, sceneHeight);

            window.setScene(scene);



            scene.setOnMouseClicked(new EventHandler<MouseEvent>() {

                @Override
                public void handle(MouseEvent event) {
                    trueMouseX = event.getX() + -1 * group.getLayoutX();
                    trueMouseY = event.getY() + -1 * group.getLayoutY();

                    if(event.getButton().equals(MouseButton.PRIMARY)) {
                        attackAll();
                       if (miniMapBorder.contains(event.getX(), event.getY())) {
                           double mouseOnMapX = (event.getX()/scaleNumber);
                           double mouseOnMapY = (event.getY()/scaleNumber);

                           if( mouseOnMapX + stage.getWidth() > rootWidth ){
                               mouseOnMapX = rootWidth - stage.getWidth();
                           }
                           if(mouseOnMapY + stage.getHeight() > rootHeight ){
                               mouseOnMapY = rootHeight - stage.getHeight();
                           }

                           group.setLayoutX(-1 * mouseOnMapX);
                           group.setLayoutY(-1 * mouseOnMapY);
                       }
                        boolean flg=false;
                        for( Dovakin d: team ){
                            if( d.mouseActivate(trueMouseX, trueMouseY)) {
                                flg=true;
                            }
                        }
                        if (!flg) {
                            System.out.println(event.getX() + "||||" + event.getY()
                            );

                        }
                    } else {
                        for( Dovakin d: team ){
                            if( d.getDovakinView().boundsInParentProperty().get().contains(event.getX(), event.getY())) {

                            }
                        }
                        tomb.composition(event);
                        treasureRoom.composition(event);
                        dragonRoom.composition(event);
                    }
                }
            });


            scene.addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {



                final KeyCombination keyCombinationFinding = new KeyCodeCombination(KeyCode.F , KeyCombination.CONTROL_DOWN);
                final KeyCombination keyCombinationSaving = new KeyCodeCombination(KeyCode.S , KeyCombination.CONTROL_DOWN);
                final KeyCombination keyCombinationLoading = new KeyCodeCombination(KeyCode.L , KeyCombination.CONTROL_DOWN);

                final KeyCombination keyCombinationRight = new KeyCodeCombination(KeyCode.RIGHT , KeyCombination.CONTROL_DOWN);
                final KeyCombination keyCombinationLeft = new KeyCodeCombination(KeyCode.LEFT , KeyCombination.CONTROL_DOWN);
                final KeyCombination keyCombinationUp = new KeyCodeCombination(KeyCode.UP , KeyCombination.CONTROL_DOWN);
                final KeyCombination keyCombinationDown = new KeyCodeCombination(KeyCode.DOWN , KeyCombination.CONTROL_DOWN);


                @Override
                public void handle(KeyEvent keyEvent) {
                    double groupX= group.getLayoutX();
                    double groupY = group.getLayoutY();
                    if (keyCombinationRight.match(keyEvent)) {
                        groupX -= screenDelta;
                        moveGroup(groupX, groupY);
                    }
                    if (keyCombinationLeft.match(keyEvent)) {
                        groupX += screenDelta;
                        moveGroup(groupX, groupY);
                    }
                    if (keyCombinationUp.match(keyEvent)) {
                        groupY += screenDelta;
                        moveGroup(groupX, groupY);
                    }
                    if (keyCombinationDown.match(keyEvent)) {
                        groupY -= screenDelta;
                        moveGroup(groupX, groupY);
                    }
                    dovakinMovementByKeys(keyEvent);
                    if (keyCombinationFinding.match(keyEvent)) {
                        FindController findController = new FindController();
                        findController.searchedListView.setItems(team);
                        findByGivenParamsStage.show();
                    }
                    if (keyCombinationSaving.match(keyEvent)) {
                        FileChooser fileChooser = new FileChooser();
                        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("XML-saving", "*.xml"),
                                new FileChooser.ExtensionFilter("TXT-saving", "*.txt"),
                                new FileChooser.ExtensionFilter("All files", "*.*"));
                        File file = fileChooser.showSaveDialog(HelloApplication.scene.getWindow());
                        if (file != null)
                            Serialization.saveGame(file);
                    }
                    if (keyCombinationLoading.match(keyEvent)) {

                            FileChooser fileChooser = new FileChooser();
                            fileChooser.setTitle("Choose a file");
                            fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("XML-збереження", "*.xml"),
                                    new FileChooser.ExtensionFilter("TXT-збереження", "*.txt"),
                                    new FileChooser.ExtensionFilter("Усі файли", "*.*"));
                            File file = fileChooser.showOpenDialog(HelloApplication.scene.getWindow());
                            if (file != null)
                                Serialization.loadGame(file);

                    }
                    if(keyEvent.getCode().equals(KeyCode.INSERT)) {
                        addDov.setScene(sceneMenu);
                        addDov.show();
                    }

                    if (keyEvent.getCode().equals(KeyCode.F)) {
                        for (Dovakin dovakin: team) {
                            dovakin.clearAim();
                        }
                    }
                    if (keyEvent.getCode().equals(KeyCode.E)) {
                        for (Dovakin dovakin: team) {
                            dovakin.clearAim();
                            tomb.exit(dovakin);
                            treasureRoom.exit(dovakin);
                            dragonRoom.exit(dovakin);
                        }
                    }
                    if (keyEvent.getCode().equals(KeyCode.Q)) {
                        attackAll();
                    }
                    if (keyEvent.getCode().equals(KeyCode.R)) {
                        for (Dragur dragur: Dragur.dragurs) {
                            for (Dovakin dovakin: team) {
                                dragur.setAim(dovakin.dovakinX, dovakin.dovakinY);
                            }
                        }
                        for (Dovakin dovakin: team) {
                            if (dovakin instanceof ExperiencedDovakin) {
                                dovakin.setAim(dragonRoom.getMacroX(), dragonRoom.getMacroY());
                            } else if (dovakin instanceof DovakinMage) {
                                dovakin.setAim(treasureRoom.getMacroX(), treasureRoom.getMacroY());
                            } else {
                                dovakin.setAim(tomb.getMacroX(), tomb.getMacroY());
                            }
                        }
                    }
                    if (keyEvent.getCode().equals(KeyCode.B)) {

                    }
                    if (keyEvent.getCode().equals(KeyCode.ESCAPE)) {
                        for(Dovakin d: team) {
                            if (d.isActive()) {
                                d.flipActivation();
                            }
                        }
                        setToZeroActiveDovakinCountAndSetLabel();
                    }
                    if (keyEvent.getCode().equals(KeyCode.DELETE)) {
                        try {
                            team.removeIf(d -> {if (d.isActive()) d.disappearWithoutFlip();
                                setDovakinCountAndSetLabel();
                                return d.isActive();
                            });
                        } catch (ConcurrentModificationException e) {
                            System.out.println("The team is empty - " + e.getMessage());
                        }
                    }
                    if (keyEvent.getCode().equals(KeyCode.C)) {
                        for (Dovakin d: Dovakin.activeDovakinList) {
                           Dovakin cloned = d.clone();
                           team.add(cloned);
                           cloned.appear();
                        }
                    }

                }
            });
            timer.start();
            window.show();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }

    }

    public static int getRootHeight() {
        return rootHeight;
    }

    public static int getRootWidth() {
        return rootWidth;
    }

    public Rectangle getVisibleZone() {
        return visibleZone;
    }

    public void setVisibleZone(Rectangle visibleZone) {
        this.visibleZone = visibleZone;
    }

    public static void setActiveDovakinCountAndSetLabel() {
        activeDovakinsNumber = Dovakin.activeDovakinList.size();
        activeDovakinsNumberLabel.setText("Number of active dovakins: " + activeDovakinsNumber);
    }
    public static void setToZeroActiveDovakinCountAndSetLabel() {
        activeDovakinsNumber = 0;
        activeDovakinsNumberLabel.setText("Number of active dovakins: " + activeDovakinsNumber);
    }
    public static void setDovakinCountAndSetLabel() {
        totalNumberOfDovakinsLabel.setText("Total number of dovakins: " + team.size());
    }
    public double getScreenWX(){
        return window.getWidth();
    }

    public double getScreenWY(){
        return window.getHeight();
    }
    public void moveGroup(double groupX, double groupY) {
        System.out.println(group.getLayoutX() + "   " + group.getLayoutY());
        System.out.println(group2.getLayoutX() + "   " + group2.getLayoutY());
        if(groupX>0)groupX=0.0;

        if( !( (-1*groupX + HelloApplication.window.getWidth()) < rootWidth ) ){
            groupX = -1*(rootWidth - window.getWidth());
        }

        if(groupY>0)groupY=0.0;

        if( !( (-1*groupY + window.getHeight() ) < rootHeight ) ){
            groupY = -1*(rootHeight - window.getHeight());
        }


        HelloApplication.group.setLayoutX(groupX);
        HelloApplication.group.setLayoutY(groupY);
    }
    public void dovakinMovementByKeys(KeyEvent keyEvent) {
        if (keyEvent.getCode().isArrowKey()) {
            for (Dovakin dovakin: team) {
                for (Dovakin dovakin1: team) {
                    if (dovakin != dovakin1) {
                        dovakin.intersect(dovakin1);
                    }
                }
            }
        }
        if(keyEvent.getCode().equals(KeyCode.UP)) {
            try {
                for (Dovakin d : Dovakin.activeDovakinList) {

                    if (tomb.tombView.boundsInParentProperty().get().intersects(d.dovakinView.boundsInParentProperty().get())) {
                        tomb.acceptDovakin(d);
                    }
                    if (treasureRoom.treasureRoomView.boundsInParentProperty().get().intersects(d.dovakinView.boundsInParentProperty().get())) {
                        treasureRoom.acceptDovakin(d);
                    }
                    if (dragonRoom.dragonRoomView.boundsInParentProperty().get().intersects(d.dovakinView.boundsInParentProperty().get())) {
                        dragonRoom.acceptDovakin(d);
                    }
                    d.walkUp();

                }
            } catch (ConcurrentModificationException e) {
                System.out.println(e.getMessage());
            }
        }
        if(keyEvent.getCode().equals(KeyCode.DOWN)) {
            try {
                for (Dovakin d : Dovakin.activeDovakinList) {
                    if (tomb.tombView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                        tomb.acceptDovakin(d);
                    }
                    if (treasureRoom.treasureRoomView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                        treasureRoom.acceptDovakin(d);
                    }
                    if (dragonRoom.dragonRoomView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                        dragonRoom.acceptDovakin(d);
                    }
                    d.walkDown();
                }
            } catch (ConcurrentModificationException e) {
                System.out.println(e.getMessage());
            }
        }
        if(keyEvent.getCode().equals(KeyCode.RIGHT)) {
            try {
                for (Dovakin d : Dovakin.activeDovakinList) {
                    if (tomb.tombView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                        tomb.acceptDovakin(d);
                    }
                    if (treasureRoom.treasureRoomView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                        treasureRoom.acceptDovakin(d);
                    }
                    if (dragonRoom.dragonRoomView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                        dragonRoom.acceptDovakin(d);
                    }
                    d.walkRight();
                }
            } catch (ConcurrentModificationException e) {
                System.out.println(e.getMessage());
            }
        }
        if(keyEvent.getCode().equals(KeyCode.LEFT)) {
            try {
                for (Dovakin d : Dovakin.activeDovakinList) {
                    if (tomb.tombView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                        tomb.acceptDovakin(d);
                    }
                    if (treasureRoom.treasureRoomView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                        treasureRoom.acceptDovakin(d);
                    }
                    if (dragonRoom.dragonRoomView.boundsInParentProperty().get().contains(d.dovakinView.boundsInParentProperty().get())) {
                        dragonRoom.acceptDovakin(d);
                    }
                    d.walkLeft();
                }
            } catch (ConcurrentModificationException e) {
                System.out.println(e.getMessage());
            }
        }
    }
    public void attackAll() {
        for (Dovakin dovakin: Dovakin.activeDovakinList) {
            for (Dragur dragur: Dragur.dragurs) {
                if (dovakin.isActive) {
                    if (dovakin.dovakinView.boundsInParentProperty().get().contains(dragur.dragurView.boundsInParentProperty().get())) {
                        dovakin.attack(dragur);
                    }
                }
            }
        }
    }
        public static void main (String[]args){
            Application.launch(args);
        }
}
