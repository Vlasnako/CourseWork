package com.mygames.thetombraiders_legendary;

public class Magic {
}
