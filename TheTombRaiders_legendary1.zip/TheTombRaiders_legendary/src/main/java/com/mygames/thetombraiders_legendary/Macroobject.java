package com.mygames.thetombraiders_legendary;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
public abstract class Macroobject {
    private static final int MAX_NUMBER = 5;
    protected Label dovakinNumber = new Label("0");
    protected int index;
    protected double macroX;
    protected double macroY;
    protected Stage MacroCompositionStage = new Stage();
    protected Group MacroCompositionGroup = new Group();
    protected Scene MacroCompositionScene = new Scene(MacroCompositionGroup, 400, 200);
    protected Button exitButton = new Button("Exit");
    protected ObservableList <Dovakin> dovakinsInMacroobjects = FXCollections.observableArrayList();

    public double getMacroX() {
        return macroX;
    }

    public void setMacroX(double macroX) {
        this.macroX = macroX;
    }

    public double getMacroY() {
        return macroY;
    }

    public void setMacroY(double macroY) {
        this.macroY = macroY;
    }

    public void acceptDovakin (Dovakin dovakin) {
        if (dovakinsInMacroobjects.size() > MAX_NUMBER) {
            System.out.println("NO SPACE IN THE MACROOBJECT");
        } else {
            dovakinsInMacroobjects.add(dovakin);
            dovakinNumber.setText(Integer.toString(dovakinsInMacroobjects.size()));
            if (dovakinsInMacroobjects.size() > MAX_NUMBER) {
                dovakinNumber.setTextFill(Color.RED);
            } else dovakinNumber.setTextFill(Color.BLACK);
            System.out.println("DOVAKIN " + dovakin + " HAS ENTERED THE MACROOBJECT");
            dovakin.disappear();
        }
    }
    public abstract void composition (MouseEvent event);
    public void exit(Dovakin exittingDovakin) {
        if (dovakinsInMacroobjects.contains(exittingDovakin)) {
            dovakinsInMacroobjects.remove(exittingDovakin);
        } else {
            return;
        }
        exittingDovakin.dragonShouts.add(new FusRoDah());
        exittingDovakin.setDovakinX(macroX - 80);
        exittingDovakin.setDovakinY(macroY + 40);
        exittingDovakin.moveImage(exittingDovakin.getDovakinX(), exittingDovakin.getDovakinY());
        exittingDovakin.appear();
        dovakinNumber.setText(Integer.toString(dovakinsInMacroobjects.size()));
    }
}
