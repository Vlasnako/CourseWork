package com.mygames.thetombraiders_legendary;

import java.util.LinkedList;

public abstract class DragonShout {
    int force;
    public abstract void shoutAction();
}
class FusRoDah extends DragonShout {
    private int push;
    @Override
    public void shoutAction() {
    }
}