package com.mygames.thetombraiders_legendary;

public class Country {
    private Tomb tomb;
    private TreasureRoom treasureRoom;
    private DragonRoom dragonRoom;
    public Country(Tomb tomb, TreasureRoom treasureRoom, DragonRoom dragonRoom) {
        this.tomb = tomb;
        this.treasureRoom = treasureRoom;
        this.dragonRoom = dragonRoom;
    }

    public Tomb getTomb() {
        return tomb;
    }

    public void setTomb(Tomb tomb) {
        this.tomb = tomb;
    }

    public TreasureRoom getTreasureRoom() {
        return treasureRoom;
    }

    public void setTreasureRoom(TreasureRoom treasureRoom) {
        this.treasureRoom = treasureRoom;
    }

    public DragonRoom getDragonRoom() {
        return dragonRoom;
    }

    public void setDragonRoom(DragonRoom dragonRoom) {
        this.dragonRoom = dragonRoom;
    }
}
