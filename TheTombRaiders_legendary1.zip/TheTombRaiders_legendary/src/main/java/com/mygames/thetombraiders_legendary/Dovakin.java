package com.mygames.thetombraiders_legendary;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

import static com.mygames.thetombraiders_legendary.HelloApplication.*;

public class Dovakin implements Serializable, Comparable<Dovakin>, Cloneable {
    static{
        activeDovakinList = FXCollections.observableArrayList();
    }
    private Image dovakin = new Image(Dovakin.class.getResource("Walk.png").toString(), 55, 90, false, false);
    protected byte autoWalk;
    protected String hierarchyOfDovakins;
    protected final int speed = 2;
    protected Rectangle activeDovakinRectangle;
    protected Rectangle attackReach;
    protected String dovakinName;
    protected Integer dovakinLevel;
    protected Double dovakinHealth;
    protected double dovakinX, dovakinY;
    private double aimx;
    private double aimy;
    protected boolean isDovakinSeen = false;
    protected boolean isActive = false;
    protected static ObservableList <Dovakin> activeDovakinList;
    protected List <DragonShout> dragonShouts;
    protected Label dovakinNameLabel;
    protected Label dovakinLevelLabel;
    protected int damage;
    protected Line healthLine;

    ImageView dovakinView = new ImageView(dovakin);
    {
        System.out.println("Init");
    }

    public String getHierarchyOfDovakins() {
        return hierarchyOfDovakins;
    }

    public void setHierarchyOfDovakins(String hierarchyOfDovakins) {
        this.hierarchyOfDovakins = hierarchyOfDovakins;
    }

    public String getDovakinName() {
        return dovakinName;
    }
    public void setDovakinName(String dovakinName) {
        this.dovakinName = dovakinName;
    }
    public int getDovakinLevel() {
        return dovakinLevel;
    }
    public void setDovakinLevel(int dovakinLevel) {
        if (dovakinLevel <= 100 && dovakinLevel > 0) {
            this.dovakinLevel = dovakinLevel;
        } else if (dovakinLevel < 0) {
            this.dovakinLevel = 1;
        } else this.dovakinLevel = 100;
    }
    public double getDovakinHealth() {
        return dovakinHealth;
    }
    public void setDovakinHealth(double dovakinHealth) {
        if (dovakinHealth <= 100 && dovakinHealth > 0) {
            this.dovakinHealth = dovakinHealth;
            //setHpLine(this.dovakinHealth);
        } else if (dovakinHealth < 0) {
            this.dovakinHealth = (double)1;
            //setHpLine(this.dovakinHealth);
        } else {
            this.dovakinHealth = (double) 100;
            //setHpLine(this.dovakinHealth);
        }
    }
    public void setDovakinX(double dovakinX) {
        this.dovakinX = dovakinX;
    }
    public double getDovakinX() {
        return dovakinX;
    }
    public void setDovakinY(double dovakinY) {
        this.dovakinY = dovakinY;
    }
    public double getDovakinY() {
        return dovakinY;
    }
    public void setHpLine (Double hP) {
        this.healthLine.setEndX(this.healthLine.getStartX()+ dovakinHealth *0.5);
    }
    public void setNameLabel (String name) {
        this.dovakinNameLabel.setText(name);
    }
    public void setLvlLabel (Integer lvl) {
        this.dovakinLevelLabel.setText(lvl.toString());
    }

    public ImageView getDovakinView() {
        return dovakinView;
    }

    public void setDovakinView(ImageView dovakinView) {
        this.dovakinView = dovakinView;
    }
    // EQUALS

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        } else
        if(o instanceof Dovakin) {
            return ((Dovakin) o).dovakinName == dovakinName &&
                    ((Dovakin) o).dovakinHealth == dovakinHealth &&
                    ((Dovakin) o).dovakinLevel == dovakinLevel;
        } else return false;
    }

    // TO STRING

    @Override
    public String toString() {
        return "Dovakin" + "{ Name: "+ dovakinName +"; Health: "+ dovakinHealth +"; lvl: "+ dovakinLevel + "}"+ "COORDS: "+ dovakinX+";" + dovakinY;
    }

    // COMPARE TO

    @Override
    public int compareTo(Dovakin anotherDovakin) {
        return this.dovakinName.compareTo(anotherDovakin.dovakinName);
    }

    // HASH CODE

    @Override
    public int hashCode() {
        return Objects.hash(hierarchyOfDovakins, dovakinName, dovakinLevel);
    }

    //  CLONE

    @Override
    public Dovakin clone() {
        Dovakin clonedDovakin = new Dovakin("Clone of " + getDovakinName(), getDovakinLevel(), getDovakinHealth(), dovakinX + 50, dovakinY);
        List <DragonShout> clonedDragonShoutList = new ArrayList<>(this.dragonShouts);
        clonedDovakin.dragonShouts = clonedDragonShoutList;

        clonedDovakin.setDovakinView(new ImageView(new Image(HelloApplication.class.getResource("Idle.png").toString(), 55, 90, false, false)));
        clonedDovakin.getDovakinView().setX(clonedDovakin.dovakinX - 5);
        clonedDovakin.getDovakinView().setY(clonedDovakin.dovakinY - 5);

        HelloApplication.setDovakinCountAndSetLabel();

        return clonedDovakin;
    }

    // COMPARATORS

    static class NameComparator implements Comparator<Dovakin> {
        @Override
        public int compare(Dovakin dovakin1, Dovakin dovakin2) {
            return dovakin1.getDovakinName().compareTo(dovakin2.getDovakinName());
        }
    }

    static class LevelComparator implements Comparator <Dovakin> {
        @Override
        public int compare(Dovakin dovakin1, Dovakin dovakin2) {
            return dovakin1.getDovakinLevel()-dovakin2.getDovakinLevel();
        }
    }

    static class healthComparator implements Comparator <Dovakin> {
        @Override
        public int compare(Dovakin dovakin1, Dovakin dovakin2) {
            return (int)((int) dovakin1.getDovakinHealth()-dovakin2.getDovakinHealth());
        }
    }

    // CONSTRUCTORS

    public Dovakin(String dovakinName, int dovakinLevel, double dovakinHealth, double x, double y ) {
        hierarchyOfDovakins = "Dovakin";
        this.dovakinName = dovakinName;
        this.autoWalk = (byte) HelloApplication.random.nextInt(8);

        dragonShouts = new ArrayList<>();

        setDovakinHealth(dovakinHealth);
        setDovakinLevel(dovakinLevel);

        this.damage = 20;

        this.dovakinX = x;
        this.dovakinY = y;

        activeDovakinRectangle = new Rectangle(65, 95);
        activeDovakinRectangle.setFill(Color.TRANSPARENT);
        activeDovakinRectangle.setStroke(Color.RED);

        attackReach = new Rectangle(65, 95);
        attackReach.setFill(Color.TRANSPARENT);
        attackReach.setStroke(Color.TRANSPARENT);

        System.out.println("Complete constructor summoned");

        dovakinNameLabel = new Label(dovakinName);

        dovakinLevelLabel = new Label(Integer.toString(getDovakinLevel()));

        dovakinView.setImage(dovakin);

        dovakinNameLabel.setLayoutX(dovakinX + 10);
        dovakinNameLabel.setLayoutY(dovakinY-40);

        healthLine = new Line();
        healthLine.setStroke(Color.LIGHTGREEN);
        healthLine.setStrokeWidth(5);

        dovakinNameLabel.setFont(Font.font("Garamond", 10));

        healthLine.setStartX(dovakinX-8);
        healthLine.setEndX(healthLine.getStartX()+ getDovakinHealth()*0.6);
        healthLine.setStartY(dovakinY-20);
        healthLine.setEndY(dovakinY-20);

        dovakinView.setX(dovakinX-5);
        dovakinView.setY(dovakinY-5);

        activeDovakinRectangle.setX(dovakinX-10);
        activeDovakinRectangle.setY(dovakinY-10);

        attackReach.setX(dovakinX - 10);
        attackReach.setY(dovakinY - 10);

        dovakinLevelLabel.setLayoutX(dovakinX-10);
        dovakinLevelLabel.setLayoutY(dovakinY-10);
    }
    public Dovakin() {
        this("Player", 1, 80, 100, 100);
        System.out.println("Default constructor summoned");
        System.out.println(getDovakinName());
        System.out.println(this);
    }

    //METHODS

    public void moveImage(double dovakinX, double dovakinY) {

        healthLine.setStartX(dovakinX-8);
        healthLine.setEndX(healthLine.getStartX() + dovakinHealth * 0.6);
        healthLine.setStartY(dovakinY-20);
        healthLine.setEndY(dovakinY-20);

        dovakinNameLabel.setLayoutX(dovakinX + 10);
        dovakinNameLabel.setLayoutY(dovakinY - 40);

        dovakinView.setX(dovakinX-5);
        dovakinView.setY(dovakinY-15);

        dovakinLevelLabel.setLayoutX(dovakinX-10);
        dovakinLevelLabel.setLayoutY(dovakinY-10);

        activeDovakinRectangle.setX(dovakinX - 10);
        activeDovakinRectangle.setY(dovakinY - 10);

        System.out.println("X_LAYOUT_DOVAKIN: " + dovakinView.getX() + " ||| Y_LAYOUT_DOVAKIN: " + dovakinView.getY());
    }

    public void walkUp() {
        dovakinY -= 5;
        moveImage(dovakinX, dovakinY);
    }
    public void walkDown() {
        dovakinY += 5;
        moveImage(dovakinX, dovakinY);
    }
    public void walkRight() {
        dovakinX += 5;
        moveImage(dovakinX, dovakinY);
    }
    public void walkLeft() {
        dovakinX -= 5;
        moveImage(dovakinX, dovakinY);
    }



    public boolean isActive() {
        return isActive;
    }
    public boolean flipActivation(){
        if(isActive){
            HelloApplication.group.getChildren().remove(activeDovakinRectangle);
            activeDovakinList.remove(this);
            HelloApplication.setActiveDovakinCountAndSetLabel();
        }
        else{
            HelloApplication.group.getChildren().add(activeDovakinRectangle);
            activeDovakinList.add(this);
            HelloApplication.setActiveDovakinCountAndSetLabel();
        }
        isActive = !isActive;

        return isActive;
    }

    public boolean mouseActivate( double mx, double my ){
        if(dovakinView.boundsInParentProperty().get().contains(mx,my)){
            flipActivation();
            return true;
        }
        return false;
    }

    public void die() {
        if(dovakinHealth <= 0) {
            HelloApplication.team.remove(this);
            disappear();
            HelloApplication.setDovakinCountAndSetLabel();
        }
    }

    public void remove() {
        HelloApplication.team.remove(this);
        disappear();
        HelloApplication.setDovakinCountAndSetLabel();
    }
    public void pickUpASkill(DragonShout dragonShout) {
        dragonShouts.add(dragonShout);
    }

    public void sneak() {
        isDovakinSeen = false;
    }

    public void appear() {
        System.out.println("APPEARED");
        HelloApplication.group.getChildren().addAll( dovakinView, dovakinLevelLabel, healthLine, dovakinNameLabel, attackReach);
    }

    public void disappear() {
        if (isActive) {
            isActive = false;
        }
        HelloApplication.group.getChildren().removeAll(dovakinView, dovakinLevelLabel, dovakinNameLabel, healthLine, activeDovakinRectangle, attackReach);
    }

    public void disappearWithoutFlip() {
        HelloApplication.group.getChildren().removeAll(dovakinView, dovakinLevelLabel, dovakinNameLabel, healthLine, activeDovakinRectangle);
    }

public void autoWalk(){
        if (!this.isActive) {

    if( isEmptyAim() ) {
        switch (this.autoWalk) {
            case 0:
                dovakinY -= this.speed;
                break;
            case 1:
                dovakinY -= this.speed;
                dovakinX += this.speed;
                break;
            case 2:
                dovakinX += this.speed;
                break;
            case 3:
                dovakinX += this.speed;
                dovakinY += this.speed;
                break;
            case 4:
                dovakinY += this.speed;
                break;
            case 5:
                dovakinY += this.speed;
                dovakinX -= this.speed;
                break;
            case 6:
                dovakinX -= this.speed;
                break;
            case 7:
                dovakinX -= this.speed;
                dovakinY -= this.speed;
                break;
        }
        if (this.dovakinView.getX() + this.dovakinView.getFitWidth() + 100 >= (HelloApplication.getRootWidth() - 100) - this.dovakinView.getFitWidth()) {
            this.autoWalk = (byte) (HelloApplication.random.nextInt(3) + 5);
        } else if (this.dovakinView.getX() <= 0) {
            this.autoWalk = (byte) (HelloApplication.random.nextInt(3) + 1);
        } else if (this.dovakinView.getY() <= 0) {
            this.autoWalk = (byte) (HelloApplication.random.nextInt(3) + 3);
        } else if (this.dovakinView.getY() + this.dovakinView.getFitHeight() >= (HelloApplication.getRootHeight() - 100)) {
            this.autoWalk = (byte) (HelloApplication.random.nextInt(2));
        }
        moveImage(dovakinX, dovakinY);
    }

    else if (!tomb.dovakinsInMacroobjects.contains(this)
            && !treasureRoom.dovakinsInMacroobjects.contains(this)
            && !dragonRoom.dovakinsInMacroobjects.contains(this)){
        if (tomb.tombView.boundsInParentProperty().get().intersects(this.dovakinView.boundsInParentProperty().get())) {
            tomb.acceptDovakin(this);
        }
        if (treasureRoom.treasureRoomView.boundsInParentProperty().get().intersects(this.dovakinView.boundsInParentProperty().get())) {
            treasureRoom.acceptDovakin(this);
        }
        if (dragonRoom.dragonRoomView.boundsInParentProperty().get().intersects(this.dovakinView.boundsInParentProperty().get())) {
            dragonRoom.acceptDovakin(this);
        }

        if ((Math.abs(dovakinX - aimx) + Math.abs(dovakinY - aimy)) < 1.0) {
            clearAim();
        } else {

            double signdx = Math.signum(aimx - dovakinX);
            double dx = Math.abs(aimx - dovakinX);
            dx = ((dx < 2) ? dx : 2);
            dx = signdx * dx;

            double signdy = Math.signum(aimy - dovakinY);
            double dy = Math.abs(aimy - dovakinY);
            dy = ((dy < 2) ? dy : 2);
            dy = signdy * dy;

            double sav_x = dovakinX;
            double sav_y = dovakinY;

            move(dx, dy);
        }

        }
    }

}
    public void move( double dx, double dy ) {
        dovakinX += dx;
        dovakinY += dy;
        moveImage(dovakinX, dovakinY);
    }
    public void setAim( double ax, double ay ){
        aimx = ax;
        aimy = ay;
    }
    public boolean isEmptyAim()
    {
        if( (aimx<0) && (aimy<0) )return true;

        return false;
    }
    public void clearAim()
    {
        aimx = aimy = -1000.0;
    }
    public void attack(Dragur dragur) {
        System.out.println("ATTACK");
        dragur.takeDamage(damage);

    }
    public void heal(double points) {
        setDovakinHealth(dovakinHealth + points);
        setHpLine(dovakinHealth);
    }
    public void takeDamage(int damage) {
        dovakinHealth -= damage;
        if (dovakinHealth <= 0) {
            die();
        }
        healthLine.setEndX(healthLine.getStartX() + dovakinHealth * 0.6);
    }
    public void intersect(Dovakin dovakin) {
        if (this.dovakinView.boundsInParentProperty().get().intersects(dovakin.dovakinView.boundsInParentProperty().get())) {
            heal(10);
            dovakin.heal(10);
        }
    }
}