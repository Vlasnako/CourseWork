package com.mygames.thetombraiders_legendary;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import java.net.URL;
import java.util.ResourceBundle;
public class TreasureRoom extends Macroobject implements Initializable{
        ListView<Dovakin> treasureRoomListView;
        Label name;
        Image treasureRoom;
        ImageView treasureRoomView;
        Rectangle walls;
        Rectangle treasureRoomBounds;
        public TreasureRoom (double macroX, double macroY) {
            this.macroX = macroX;
            this.macroY = macroY;
            MacroCompositionStage.setResizable(false);
            dovakinNumber = new Label("0");
            walls = new Rectangle(250, 200);
            treasureRoomBounds = new Rectangle(300, 100);
            name = new Label("TREASURE ROOM");
            name.setFont(Font.font("Times New Roman", 20));
            dovakinNumber.setFont(Font.font("Times New Roman", 20));
            treasureRoom = new Image(DragonRoom.class.getResource("Yellow_ruins3.png").toString(), 300, 250, false, false);
            treasureRoomView = new ImageView(treasureRoom);
            treasureRoomView.setX(macroX);
            treasureRoomView.setY(macroY);
            name.setLayoutX(macroX + 100);
            name.setLayoutY(macroY + 70);
            dovakinNumber.setLayoutX(macroX + 280);
            dovakinNumber.setLayoutY(macroY + 70);
            walls.setX(macroX);
            walls.setY(macroY);
            walls.setFill(Color.TRANSPARENT);
            walls.setStroke(Color.DARKORANGE);
            treasureRoomBounds.setX(macroX - 100);
            treasureRoomBounds.setY(macroY + 40);
            treasureRoomBounds.setFill(Color.TRANSPARENT);
            treasureRoomBounds.setStroke(Color.TRANSPARENT);
            MacroCompositionStage.setScene(MacroCompositionScene);
            treasureRoomListView = new ListView<>();
            exitButton.setLayoutX(280);
            exitButton.setLayoutY(90);
            MacroCompositionGroup.getChildren().addAll(treasureRoomListView, exitButton);

            HelloApplication.group.getChildren().addAll(walls, treasureRoomView, name, treasureRoomBounds, dovakinNumber);

        }
        @Override

        public void initialize(URL url, ResourceBundle rb) {
            treasureRoomListView.setItems(dovakinsInMacroobjects);
            index = treasureRoomListView.getSelectionModel().getSelectedIndex();
        }
        public void composition (MouseEvent event) {
            if (treasureRoomView.boundsInParentProperty().get().contains(HelloApplication.trueMouseX,
                    HelloApplication.trueMouseY)) {
                treasureRoomListView.setItems(dovakinsInMacroobjects);
                MacroCompositionStage.show();
            }
            exitButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    try {
                        System.out.println("DOVAKIN " + dovakinsInMacroobjects.get(index) + " HAS_LEFT_THE_TREASURE_ROOM");
                        System.out.println(index);
                        Dovakin exittingDovakin = dovakinsInMacroobjects.remove(index);
                        exittingDovakin.setDovakinX(macroX);
                        exittingDovakin.setDovakinY(macroY + 40);
                        exittingDovakin.moveImage(macroX, macroY + 40);
                        exittingDovakin.appear();
                        dovakinNumber.setText(Integer.toString(dovakinsInMacroobjects.size()));
                    } catch (IndexOutOfBoundsException e) {
                        System.out.println(e.getMessage());
                    }
                }
            });
        }





}
