package com.mygames.thetombraiders_legendary;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

import static com.mygames.thetombraiders_legendary.HelloApplication.team;

public class FindController implements Initializable {
    @FXML
    Button inTombButton;
    @FXML
    Button inTreasureRoomButton;
    @FXML
    Button inDragonRoomButton;
    @FXML
    TextField nameToFind;
    @FXML
    TextField lvlToFind;
    @FXML
    ListView <Dovakin> searchedListView = new ListView<>();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        searchedListView.setItems(team);
        searchedListView.refresh();
    }
    public void search() {
        ObservableList <Dovakin> searchedList = FXCollections.observableArrayList();
        if (lvlToFind.getText().equals("")) {
            for (Dovakin d: team) {
                if (nameToFind.getText().equals(d.getDovakinName())) {
                    searchedList.add(d);
                }
            }
            searchedListView.setItems(searchedList);
            searchedListView.refresh();
        } if (nameToFind.getText().equals("") && lvlToFind.getText().equals("")) {
            searchedListView.setItems(team);
            searchedListView.refresh();
        }
    }
    public void showDovakinsInTomb() {
        searchedListView.setItems(HelloApplication.tomb.dovakinsInMacroobjects);
        searchedListView.refresh();
    }
    public void showDovakinsInTreasureRoom() {
        searchedListView.setItems(HelloApplication.treasureRoom.dovakinsInMacroobjects);
        searchedListView.refresh();
    }
    public void showDovakinsInDragonRoom() {
        searchedListView.setItems(HelloApplication.dragonRoom.dovakinsInMacroobjects);
        searchedListView.refresh();
    }
    public void showDovakinsEverywhere() {
        searchedListView.setItems(team);
        searchedListView.refresh();
    }

    @FXML
    private void sortContentByName() {
        ObservableList<Dovakin> sortedList = FXCollections.observableArrayList();
        sortedList.setAll(searchedListView.getItems());
        FXCollections.sort(sortedList, new Dovakin.NameComparator());
        searchedListView.setItems(sortedList);
        searchedListView.refresh();
    }
    @FXML
    private void sortContentByLevel() {
        ObservableList<Dovakin> sortedList = FXCollections.observableArrayList();
        sortedList.setAll(searchedListView.getItems());
        FXCollections.sort(sortedList, (d1, d2) -> d1.getDovakinLevel() - d2.getDovakinLevel());
        searchedListView.setItems(sortedList);
        searchedListView.refresh();
    }
    @FXML
    private void sortContentByHealth() {
        ObservableList<Dovakin> sortedList = FXCollections.observableArrayList();
        sortedList.setAll(searchedListView.getItems());
        FXCollections.sort(sortedList, (d1, d2) -> (int) (d1.getDovakinHealth() - d2.getDovakinHealth()));
        searchedListView.setItems(sortedList);
        searchedListView.refresh();
    }
    @FXML
    public void showDovakinsOutside() {
        ObservableList<Dovakin> sortedList = FXCollections.observableArrayList();
        sortedList.setAll(team);
        sortedList.removeAll(HelloApplication.tomb.dovakinsInMacroobjects);
        sortedList.removeAll(HelloApplication.treasureRoom.dovakinsInMacroobjects);
        sortedList.removeAll(HelloApplication.dragonRoom.dovakinsInMacroobjects);
        searchedListView.setItems(sortedList);
        searchedListView.refresh();
    }
}
