package com.mygames.thetombraiders_legendary;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Serialization {
    public static void saveGame(File file) {
        XMLEncoder encoder;
        try {
            encoder = new XMLEncoder(new BufferedOutputStream(new FileOutputStream(file)));

            HashMap<String, Object> hashMap = new HashMap<>();
            ArrayList <Dovakin> dovakins = new ArrayList<>(HelloApplication.team);
            ArrayList <Dragur> dragurs = new ArrayList<>(Dragur.dragurs);
            hashMap.put("dovakins", dovakins);
           // hashMap.put("dragurs",dragurs);
            encoder.writeObject(hashMap);
            encoder.close();
        } catch (FileNotFoundException e) {
            System.out.println("Помилка відкриття файлу");
        }
    }
    public static void loadGame(File file){
        XMLDecoder decoder;
        try {
            decoder=new XMLDecoder(new BufferedInputStream(new FileInputStream(file)));
            for (int i = 0; i< HelloApplication.team.size(); i++){
                Dovakin dovakin = HelloApplication.team.remove(i--);
                if (!dovakin.isActive) {
                    dovakin.disappearWithoutFlip();
                } else dovakin.disappear();
            }

            HashMap<String, Object> hashMap = (HashMap<String, Object>)decoder.readObject();

            for (Dovakin dovakin: (ArrayList<Dovakin>)hashMap.get("dovakins")){
                HelloApplication.team.add(dovakin);
                dovakin.appear();
            }
//            for (Dragur dragur:(ArrayList<Dragur>)hashMap.get("dragurs")){
//                Dragur.dragurs.add(dragur);
//                dragur.appear();
//            }
            decoder.close();
        } catch (FileNotFoundException e) {
            System.out.println("Помилка відкриття файлу");
        }
    }
}
